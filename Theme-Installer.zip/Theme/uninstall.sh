bash <(curl -s https://pterodactyl-installer.se) <<EOF
6
y
y
y
y
EOF

echo "Proses Uninstall Panel Selesai."
